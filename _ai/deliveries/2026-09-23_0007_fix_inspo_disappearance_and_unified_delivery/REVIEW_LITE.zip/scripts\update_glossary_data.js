const fs = require('fs');
const path = require('path');

const glossary = [
  // ==========================================
  // 一、制作人核心功能与界面按钮 (UI Core)
  // ==========================================
  {
    "id": "custom_mode",
    "term": "Advanced",
    "category": "ui_core",
    "zh_name": "自己写歌词和风格",
    "tier1_vernacular": "点这里才能自己填词、自己写风格。创作页有三个模式：Simple 是只丢一句给它自己猜；Advanced 才能自己写歌词和风格；Sounds 是做一段声音，不是一整首歌。",
    "tier2_suno_usage": "做歌推荐用这个模式。点开 Advanced 后，页面会出现歌词框和风格描述框。",
    "tier3_example": "想要自己写歌词，或者想指定用哪种乐器、哪种气氛，都在 Advanced 里面做。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "旧词 id custom_mode 保留，term 已由 Custom 修正为 Advanced"
  },
  {
    "id": "instrumental",
    "term": "Instrumental",
    "category": "ui_core",
    "zh_name": "纯音乐",
    "tier1_vernacular": "整首歌只有乐器演奏，没有人声唱歌或说话。页面上没有单独的纯音乐开关，想要纯音乐，就在 Advanced 模式下把歌词框完全留空。",
    "tier2_suno_usage": "在 Advanced 模式下，歌词框一个字都不要填。风格框里写上想要的乐器和气氛，做出来的就是纯乐器演奏。",
    "tier3_example": "歌词框留空，风格框写 acoustic guitar, slow，生成的就是纯木吉他慢曲。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "已按真实创作页更正：无独立开关，纯音乐通过歌词框留空实现"
  },
  {
    "id": "simple",
    "term": "Simple",
    "category": "ui_core",
    "zh_name": "丢一句给它写",
    "tier1_vernacular": "最简单的傻瓜模式。你只要输入一句话，比如写一首关于夏天的歌，AI 就会全权替你写歌词、配乐曲。",
    "tier2_suno_usage": "适合没有灵感只想随手试试的时候。如果想自己控制歌词和具体乐器，请切换到旁边的 Advanced 模式。",
    "tier3_example": "适合一键开盲盒体验，日常创作建议使用 Advanced。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增 UI 核心按钮词条"
  },
  {
    "id": "sounds",
    "term": "Sounds",
    "category": "ui_core",
    "zh_name": "做一段声音",
    "tier1_vernacular": "用来生成一段简短的音效、鼓点循环或环境声，不是做一整首有头有尾的歌曲。",
    "tier2_suno_usage": "旁边配有单次发声、循环播放以及音调选择。做第一首完整歌曲时不要选这个模式。",
    "tier3_example": "适合为视频剪辑做雨声、心跳、单次转场特效声或鼓点循环素材。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增 UI 核心按钮词条"
  },
  {
    "id": "model_version",
    "term": "v6",
    "category": "ui_core",
    "zh_name": "现在常用的模型",
    "tier1_vernacular": "Suno 创作菜单里主要有 v6、v6-wild、v6-mini。v6 是日常最常用的模型，唱得最稳，声音最清晰自然。个人页旧歌上的 V4.5 只是历史生成的标记。",
    "tier2_suno_usage": "写歌默认选 v6 即可。如果想更天马行空可以选 v6-wild，如果想省点数可以用 v6-mini。",
    "tier3_example": "第一首歌建议直接留在 v6，生成效果最稳妥。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "旧词 id 保留，term 修正为 v6"
  },
  {
    "id": "v6_wild",
    "term": "v6-wild",
    "category": "ui_core",
    "zh_name": "更敢试、更怪",
    "tier1_vernacular": "比常规 v6 更具实验性的模型版本。它的旋律变化更大、编曲想法更怪、更敢打破常规套路。",
    "tier2_suno_usage": "当你觉得普通模型生成的曲子听起来太千篇一律时，可以切到 v6-wild 碰碰奇特创意。",
    "tier3_example": "适合先锋前卫风格或想找不寻常灵感时使用。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增模型子版本词条"
  },
  {
    "id": "v6_mini",
    "term": "v6-mini",
    "category": "ui_core",
    "zh_name": "免费档，更省",
    "tier1_vernacular": "免费用户常用的轻量模型版本。生成速度很快，消耗额度更省，但在声音细节和真实度上比不上完整版 v6。",
    "tier2_suno_usage": "想要快速测试旋律草稿或节省点数时可以选用。",
    "tier3_example": "适合快速试听摸索结构，定稿推荐切回常规 v6。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增模型子版本词条"
  },
  {
    "id": "create_song",
    "term": "Create song",
    "category": "ui_core",
    "zh_name": "做歌，一次两首",
    "tier1_vernacular": "核心生成按钮。点一次会消耗点数，并在右侧同时生成两首不同感觉的歌曲供你挑选。",
    "tier2_suno_usage": "歌词与风格都填好后点击。如果输入框全空，这个按钮会保持灰色不可点击。",
    "tier3_example": "两首生成完成后全部听一遍，挑出更符合你心中预期的那一首保留。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增核心生成按钮"
  },
  {
    "id": "extend",
    "term": "Extend",
    "category": "ui_core",
    "zh_name": "顺畅续写下一段",
    "tier1_vernacular": "Suno 一次通常只做两到四分钟。如果歌还没唱完，或者想再加一段尾奏，可以用这个功能从指定的那一秒接着往后唱。",
    "tier2_suno_usage": "在喜欢的歌曲三点菜单选 Extend，设置从几分几秒接着唱，然后填入新段落的词。",
    "tier3_example": "原曲在一分五十秒突然戛然而止，设置 Extend from 01:45，输入新歌词继续写完。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "正文按通俗听感重写，去括号"
  },
  {
    "id": "get_stems",
    "term": "Get Stems",
    "category": "ui_core",
    "zh_name": "分轨提取",
    "tier1_vernacular": "把已经做好的歌拆开，人声归人声，乐器归乐器。Pro 账号有两种分轨方式：Auto 是从一批乐器里自动拆，Split from mix 是自己选一种乐器拆。",
    "tier2_suno_usage": "在歌曲菜单里点 Get Stems。做第一首歌先不用分轨。第三种 Advanced split 点开需要 Premier 会员，教程不走那里。",
    "tier3_example": "想把做好的歌拿掉人声当伴奏，或者只要单独的人声干声，用 Auto 分轨即可。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "正文按 Pro 会员权限校对更正"
  },
  {
    "id": "reuse_prompt",
    "term": "Reuse Prompt",
    "category": "ui_core",
    "zh_name": "复用提示词与参数",
    "tier1_vernacular": "一键抄作业。把你或别人某首好听的歌所用的歌词、风格词、参数原样拷贝回左侧编辑区，方便微调。",
    "tier2_suno_usage": "在歌曲菜单点击 Reuse Prompt，左侧输入框会立刻填好原配方，改动几个词就能重试。",
    "tier3_example": "看到别人做出的曲子质感很好，点击复用，把歌词换成你自己的，就能做出同款风格。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "正文重写，去括号"
  },
  {
    "id": "replace_section",
    "term": "Replace Section",
    "category": "ui_core",
    "zh_name": "局部重做指定片段",
    "tier1_vernacular": "局部橡皮擦。整首歌旋律很好，偏偏某一句发音怪或者中间有杂音，用这个功能只把那几秒重新做一遍，其余好听部分不动。",
    "tier2_suno_usage": "在歌曲菜单选 Edit 里的 Replace Section，拖动波形选择有问题的几秒区间，改好对应歌词后重新生成。",
    "tier3_example": "三十秒处某个字念错了，框选二十八秒到三十三秒，修正歌词后局部重新生成。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "正文重写，去括号"
  },
  {
    "id": "crop",
    "term": "Crop Audio",
    "category": "ui_core",
    "zh_name": "裁剪音频时长",
    "tier1_vernacular": "类似手机相册剪裁照片。直接把歌曲开头多余的空白、或者结尾拖沓的杂音裁掉。",
    "tier2_suno_usage": "在歌曲菜单选 Crop Audio，拖动左右两端的时间指针，保存为一个干净的新片段。",
    "tier3_example": "歌曲前十五秒没有任何声音，拖动左端滑块到第十五秒，切出一个利落的开头。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "正文重写，去括号"
  },
  {
    "id": "remove_section",
    "term": "Remove Section",
    "category": "ui_core",
    "zh_name": "删掉指定片段",
    "tier1_vernacular": "直接把歌曲中间多余难听的一小截完全切除，让前后两段直接接在一起。",
    "tier2_suno_usage": "在歌曲 Edit 菜单里选择 Remove Section，选定想要拿掉的起止时间点确认删除。",
    "tier3_example": "歌词中间有一段重复冗长的过门，直接选定该区间删除，前后平滑拼接。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增 UI 核心功能"
  },
  {
    "id": "fade_in",
    "term": "Fade In",
    "category": "ui_core",
    "zh_name": "开头声音渐渐变大",
    "tier1_vernacular": "声音从完全静音开始，慢慢增大到正常音量，听起来非常温柔，不会一上来就很突兀。",
    "tier2_suno_usage": "在歌曲 Edit 菜单里设置 Fade In，给开头几秒加上平滑渐入效果。",
    "tier3_example": "适合安静抒情歌曲的开头，让声音像缓缓走来一样自然出现。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增 UI 核心功能"
  },
  {
    "id": "fade_out_action",
    "term": "Fade Out",
    "category": "ui_core",
    "zh_name": "结尾声音渐渐变小",
    "tier1_vernacular": "声音在歌曲结尾慢慢变轻变弱，最后消失在安静中，适合收尾没有做好的歌曲。",
    "tier2_suno_usage": "在歌曲 Edit 菜单里设置 Fade Out，为尾声加上自然淡出。",
    "tier3_example": "结尾突然掐断很不舒服时，用 Fade Out 渐弱收尾最为自然。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增 UI 编辑动作词条"
  },
  {
    "id": "adjust_speed",
    "term": "Adjust Speed",
    "category": "ui_core",
    "zh_name": "调整整首歌快慢",
    "tier1_vernacular": "在不改变音调高低的前提下，把整首歌变快一些或者变慢一些。",
    "tier2_suno_usage": "在歌曲菜单里点击 Adjust Speed，拖动速度滑块试听并保存新版本。",
    "tier3_example": "慢情歌想要更加欢快跳跃，可以把速度微调加快百分之十。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增 UI 核心功能"
  },
  {
    "id": "remaster",
    "term": "Remaster",
    "category": "ui_core",
    "zh_name": "重新润色音质",
    "tier1_vernacular": "用更新的声音处理算法，把原来发闷、发杂的歌曲重新过一遍，让声音更通透清晰、声场更宽阔。",
    "tier2_suno_usage": "在歌曲菜单里点击 Remaster，系统会生成一份更高音质的新版本。",
    "tier3_example": "早期版本做的老歌声音略显浑浊，点击 Remaster 即可提升现代清晰度。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增 UI 核心功能"
  },
  {
    "id": "persona",
    "term": "Voice",
    "category": "ui_core",
    "zh_name": "专属音色",
    "tier1_vernacular": "固定喜欢的歌手音色。如果哪首歌里的人声音色特别好听，可以保存下来用于后面的新歌。注意：Create Persona 在当前菜单未直接出现，标 NOT_YET_VERIFIED。",
    "tier2_suno_usage": "在 Remix 菜单中可见 Voice 选项。后续写新歌时关联该音色即可延续同款嗓音。",
    "tier3_example": "打造专属虚拟歌手时使用，保持每次作品人声辨识度统一。",
    "prompt_tag": "",
    "expert_status": "NOT_YET_VERIFIED",
    "expert_notes": "term 改为 Voice，Create Persona 标注 NOT_YET_VERIFIED"
  },
  {
    "id": "cover_song",
    "term": "Cover Song",
    "category": "ui_core",
    "zh_name": "根据旋律翻唱新风格",
    "tier1_vernacular": "保留原本的歌词和大概旋律骨架，完全换一套编曲流派和伴奏风格，类似歌手去翻唱别人的经典老歌。",
    "tier2_suno_usage": "在歌曲菜单里点 Cover Song，填入全新的风格词重新生成。",
    "tier3_example": "把原本轻柔的木吉他民谣，一键翻唱成节奏强劲的摇滚或电子舞曲。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "正文重写，去括号"
  },
  {
    "id": "upload_audio",
    "term": "Upload Audio",
    "category": "ui_core",
    "zh_name": "上传参考音频",
    "tier1_vernacular": "用自己手机录制的一段清唱、吹口哨或者乐器弹奏，作为这首歌的创作起点。",
    "tier2_suno_usage": "点击上传本地音频文件，Suno 会识别你的旋律走向并以此为基础做完整的专业编曲。",
    "tier3_example": "自己哼唱了半分钟的一句旋律，上传上去让 AI 扩写成一首配器齐全的完整歌曲。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "正文重写，去括号"
  },
  {
    "id": "exclude_styles",
    "term": "Exclude styles",
    "category": "ui_core",
    "zh_name": "排除不想要的风格",
    "tier1_vernacular": "负向提示词。明确告诉 AI 这首歌里绝对不要出现什么元素，比如不要刺耳失真、不要重低音、不要嘈杂喊叫。",
    "tier2_suno_usage": "在 Advanced 模式下展开 More Options，在 Exclude styles 输入框里填写你不想要的英文标签。",
    "tier3_example": "heavy metal, shouting",
    "prompt_tag": "heavy metal, shouting",
    "expert_status": "reviewed",
    "expert_notes": "保留简短英文示例，正文去括号"
  },
  {
    "id": "weirdness_vibe",
    "term": "Weirdness",
    "category": "ui_core",
    "zh_name": "创意发散程度",
    "tier1_vernacular": "控制 AI 构思旋律时有多大胆。拉得较低时走稳妥好听的流行路线；拉高时会尝试怪诞、前卫或意想不到的走向。滑块约百分之五十时页面显示为 Expected results。",
    "tier2_suno_usage": "在 Advanced 模式展开的 More Options 中拖动。普通写歌保持在中间位置即可。",
    "tier3_example": "想要一首顺耳的流行情歌就调低，想要搞先锋实验音乐就调高。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "正文注明中间值为 Expected results"
  },
  {
    "id": "vocal_gender",
    "term": "Vocal Gender",
    "category": "ui_core",
    "zh_name": "选男声或女声",
    "tier1_vernacular": "直接指定主唱的性别。可以选男声 Male，也可以选女声 Female。",
    "tier2_suno_usage": "在 Advanced 模式展开的 More Options 中勾选对应选项。",
    "tier3_example": "写闺蜜心事选 Female，写深沉叙事选 Male。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增 More Options 参数词条"
  },
  {
    "id": "style_influence",
    "term": "Style Influence",
    "category": "ui_core",
    "zh_name": "风格词影响程度",
    "tier1_vernacular": "控制你在风格框里写的那些形容词有多大分量。调高会严格贴合你的文字，调低则让模型自由发挥更多。",
    "tier2_suno_usage": "在 More Options 里拖动滑块，默认居中通常为 Moderate 中度影响。",
    "tier3_example": "填了很具体的乐器希望百分百体现时，可以稍微拉高此项。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增 More Options 参数词条"
  },
  {
    "id": "variety",
    "term": "Variety",
    "category": "ui_core",
    "zh_name": "结果差异程度",
    "tier1_vernacular": "控制每次同时生成的两首歌曲之间差别有多大。拉高会让两首非常不一样，拉低会让两首比较接近。",
    "tier2_suno_usage": "在 More Options 里调节，默认通常是 Balanced variety 均衡差异。",
    "tier3_example": "想一次探索截然不同的旋律走向可以调高此项。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增 More Options 参数词条"
  },
  {
    "id": "my_taste",
    "term": "My Taste",
    "category": "ui_core",
    "zh_name": "按我的听歌偏好",
    "tier1_vernacular": "根据你以往常听、常点赞和常生成的风格偏好，为新歌自动注入符合你个人口味的微调。",
    "tier2_suno_usage": "在 More Options 里开关此项，有 Off 和 On 两个档位。",
    "tier3_example": "打开后生成的作品会更容易贴合你平时的听歌习惯。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增 More Options 参数词条"
  },
  {
    "id": "max_mode",
    "term": "Max Mode",
    "category": "ui_core",
    "zh_name": "开启深度生成",
    "tier1_vernacular": "投入更多算力对整首歌的编曲细节、声学空间和发音进行更深入的精细打磨。",
    "tier2_suno_usage": "在 More Options 里开启，适合正式发布级别的重要歌曲。",
    "tier3_example": "写重要作品或追求极致听感时打开。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增 More Options 参数词条"
  },
  {
    "id": "song_title",
    "term": "Song Title",
    "category": "ui_core",
    "zh_name": "歌曲标题",
    "tier1_vernacular": "为你的歌曲起一个名字。如果不填，系统会根据歌词内容自动替你拟一个标题。",
    "tier2_suno_usage": "在 More Options 里的输入框填写自己想要的歌名，可以随时修改。",
    "tier3_example": "如填写 雨夜街角 或者留空由 AI 自动命名。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增 More Options 词条"
  },
  {
    "id": "duration_custom",
    "term": "Duration Custom",
    "category": "ui_core",
    "zh_name": "自己定长短",
    "tier1_vernacular": "这是歌曲时长的长短设置，不是模式开关。在这里可以手动指定想要生成的歌曲具体几分几秒。",
    "tier2_suno_usage": "在 Duration 选项中选择 Custom，即可自行拖动或输入期望的音频时间长度。",
    "tier3_example": "如果只需要三十秒短视频配乐，选 Custom 设置为三十秒即可。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "严格区分于制作人模式，注明为时长设置"
  },
  {
    "id": "duration_auto",
    "term": "Duration Auto",
    "category": "ui_core",
    "zh_name": "系统自动决定长短",
    "tier1_vernacular": "时长交给 AI 自动把控。它会根据你歌词的长短和曲风自然收尾，不需要你手动限制时间。",
    "tier2_suno_usage": "在 Duration 选项中选择 Auto，这是日常做歌的默认推荐设置。",
    "tier3_example": "写完一段歌词直接选 Auto，系统会唱到歌词自然结束。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增时长选项词条"
  },
  {
    "id": "mashup",
    "term": "Mashup",
    "category": "ui_core",
    "zh_name": "两首歌揉合",
    "tier1_vernacular": "把两首不同歌曲的特色巧妙融合在一起，比如把一首歌的旋律套进另一首歌的节奏和编曲里。",
    "tier2_suno_usage": "在歌曲 Remix 菜单里选择 Mashup，挑选另一首作为对照样本进行混搭。",
    "tier3_example": "把国风民乐的曲调与现代电子舞曲的鼓点揉合生成新潮曲风。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增 Remix 选项词条"
  },
  {
    "id": "sample_this_song",
    "term": "Sample this song",
    "category": "ui_core",
    "zh_name": "截取一段当新歌素材",
    "tier1_vernacular": "音乐采样。从这首歌里截取一段非常好听的鼓点、吉他声或一小句哼唱，拿来当作下一首新歌的种子素材。",
    "tier2_suno_usage": "在歌曲菜单里点击 Sample this song，选定想要采样的范围后基于它开启新创作。",
    "tier3_example": "听到一段带感的萨克斯过门，采样后作为新歌的开头动机。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增 Remix 选项词条"
  },
  {
    "id": "use_as_inspiration",
    "term": "Use as Inspiration",
    "category": "ui_core",
    "zh_name": "拿这首歌的气氛当灵感",
    "tier1_vernacular": "参考这首歌的情绪、乐器编排和快慢节奏，以此为参考基调去做一首全新的歌曲。",
    "tier2_suno_usage": "在歌曲菜单里点击 Use as Inspiration，系统会自动吸取其风格骨架投喂给新表单。",
    "tier3_example": "喜欢某首歌的慵懒晚风氛围，用作灵感参考做一首同样感觉但歌词不同的新歌。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增功能选项词条"
  },
  {
    "id": "reverse",
    "term": "Reverse",
    "category": "ui_core",
    "zh_name": "声音倒放",
    "tier1_vernacular": "把整段声音从尾到头倒着播放，产生一种奇幻、悬疑、像时间倒流一样的特殊音响效果。",
    "tier2_suno_usage": "在歌曲 Edit 菜单里选择 Reverse 进行倒放渲染。",
    "tier3_example": "用来制作梦境、神秘回忆或前卫迷幻音乐里的特殊转场声效。",
    "prompt_tag": "",
    "expert_status": "reviewed",
    "expert_notes": "新增 Edit 选项词条"
  },
  {
    "id": "add_vocal",
    "term": "Add Vocal",
    "category": "ui_core",
    "zh_name": "给伴奏加人声",
    "tier1_vernacular": "为一段已经做好的纯乐器伴奏补充填入人声演唱。注意：套餐对比表显示 Pro 具备此功能，但生成路径未走完，标注 NOT_YET_VERIFIED。",
    "tier2_suno_usage": "在现有伴奏曲目的菜单中触发，填入想唱的歌词与人声类型后提交生成。",
    "tier3_example": "之前做好的纯音乐很好听，后续想加一段人声歌词时使用。",
    "prompt_tag": "",
    "expert_status": "NOT_YET_VERIFIED",
    "expert_notes": "标注 NOT_YET_VERIFIED，套餐对比表列为 Pro 功能但生成未实测闭环"
  },

  // ==========================================
  // 二、歌曲结构骨干语法 (Song Structure)
  // ==========================================
  {
    "id": "intro",
    "term": "[Intro]",
    "category": "song_structure",
    "zh_name": "前奏",
    "tier1_vernacular": "歌曲刚开始还没开口唱歌的那几秒乐器演奏，用来把听众带入歌曲的气氛中。",
    "tier2_suno_usage": "放在歌词最开头。方括号是给 Suno 看的路标，中文写在下一行，不是唱出来的词。",
    "tier3_example": "[Intro]\n吉他轻轻弹奏，没有歌声",
    "prompt_tag": "[Intro]",
    "expert_status": "reviewed",
    "expert_notes": "去括号，规范路标说明"
  },
  {
    "id": "verse",
    "term": "[Verse]",
    "category": "song_structure",
    "zh_name": "在讲事情的一段",
    "tier1_vernacular": "主歌，交代故事经过的段落。像平时平淡说话一样娓娓道来，唱得比较平，用来把事情交代清楚。",
    "tier2_suno_usage": "通常用三四句把事情说完。第一首做歌建议只写一段讲事情、一段最想被记住的段落。",
    "tier3_example": "[Verse]\n路灯亮了，店门已经拉下\n我还站在昨天告别的地方\n风把话吹得很轻",
    "prompt_tag": "[Verse]",
    "expert_status": "reviewed",
    "expert_notes": "文案与教程第 3 步完全同义对齐"
  },
  {
    "id": "pre_chorus",
    "term": "[Pre-Chorus]",
    "category": "song_structure",
    "zh_name": "导歌，情绪爬坡",
    "tier1_vernacular": "在讲完事情之后、高潮到来之前的过渡几句。乐器开始变多，节奏变密，情绪一步一步向上推。",
    "tier2_suno_usage": "放在讲事情段落之后、核心高潮段落之前，起到蓄力推动的作用。",
    "tier3_example": "[Pre-Chorus]\n心跳越来越快\n脚步不再徘徊",
    "prompt_tag": "[Pre-Chorus]",
    "expert_status": "reviewed",
    "expert_notes": "去括号，强化日常听感"
  },
  {
    "id": "chorus",
    "term": "[Chorus]",
    "category": "song_structure",
    "zh_name": "最想被人记住的那几句",
    "tier1_vernacular": "副歌，整首歌最抓耳、最响亮、唱完让人忍不住跟着哼的高潮段落。通常在一首歌里重复出现两到三次。",
    "tier2_suno_usage": "只写最想被人记住的两三句。在第二段和第四段使用同样的词，人能记住的就是这种重复。",
    "tier3_example": "[Chorus]\n你要是回头看一眼\n我就把灯再亮久一点",
    "prompt_tag": "[Chorus]",
    "expert_status": "reviewed",
    "expert_notes": "文案与教程第 3 步完全同义对齐"
  },
  {
    "id": "bridge",
    "term": "[Bridge]",
    "category": "song_structure",
    "zh_name": "过渡转折段",
    "tier1_vernacular": "桥段。整首歌唱了大半后，突然换一种旋律走向或完全换一种语气，给人耳目一新的感觉，避免听腻。",
    "tier2_suno_usage": "通常放在第二次高潮之后，唱完后再接最后一次最高潮收尾。",
    "tier3_example": "[Bridge]\n如果时光能倒流\n谁会在下一个路口守候",
    "prompt_tag": "[Bridge]",
    "expert_status": "reviewed",
    "expert_notes": "去括号，通俗化重写"
  },
  {
    "id": "drop",
    "term": "[Drop]",
    "category": "song_structure",
    "zh_name": "高潮爆发点",
    "tier1_vernacular": "电子舞曲里的招牌瞬间。前面节奏一直憋着、垫着，突然一声巨响，强烈的重低音和鼓点全部放开喷涌而出。",
    "tier2_suno_usage": "写在蓄力铺垫段落之后，提示词可写重低音爆发。",
    "tier3_example": "[Drop]\n重低音与鼓点全力爆发",
    "prompt_tag": "[Drop]",
    "expert_status": "reviewed",
    "expert_notes": "去括号，日常听感描绘"
  },
  {
    "id": "hook",
    "term": "[Hook]",
    "category": "song_structure",
    "zh_name": "最想被人记住的那句",
    "tier1_vernacular": "像钩子一样死死勾住耳朵的一小句旋律或词，整首歌里听一遍就忘不掉。注意必须带方括号才表示歌词路标，底栏 Hooks 是短视频功能，不要混淆。",
    "tier2_suno_usage": "放在歌词里标记最核心的那一句毒性旋律。",
    "tier3_example": "[Hook]\n夜太美，哪怕再黑也无所谓",
    "prompt_tag": "[Hook]",
    "expert_status": "reviewed",
    "expert_notes": "去括号，严格强调带方括号与底栏短视频区分"
  },
  {
    "id": "guitar_solo",
    "term": "[Guitar Solo]",
    "category": "song_structure",
    "zh_name": "吉他独奏段",
    "tier1_vernacular": "唱歌停下来，专门留出十秒到二十秒让吉他单独展现华丽旋律的乐段。",
    "tier2_suno_usage": "放在高潮之后或桥段之中，提示 AI 此处不要有人唱歌，只展示吉他弹奏。",
    "tier3_example": "[Guitar Solo]\n电吉他独奏激昂高音",
    "prompt_tag": "[Guitar Solo]",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "piano_solo",
    "term": "[Piano Solo]",
    "category": "song_structure",
    "zh_name": "钢琴独奏段",
    "tier1_vernacular": "人声停歇，黑白琴键清澈跳动，单独用钢琴声诉说情感的优美段落。",
    "tier2_suno_usage": "适合抒情慢歌的间奏部分，营造安静深情的氛围。",
    "tier3_example": "[Piano Solo]\n清澈钢琴独奏慢慢流淌",
    "prompt_tag": "[Piano Solo]",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "build_up",
    "term": "[Build-Up]",
    "category": "song_structure",
    "zh_name": "蓄力爬坡段",
    "tier1_vernacular": "鼓点从慢变快，声音由轻渐响，音调越来越高，把所有人的情绪不断往上推，等待最后一瞬间爆发。",
    "tier2_suno_usage": "通常放在副歌或高潮爆发点之前，用于积攒巨大的听觉张力。",
    "tier3_example": "[Build-Up]\n密集鼓点加快，音量不断攀升",
    "prompt_tag": "[Build-Up]",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "breakdown",
    "term": "[Breakdown]",
    "category": "song_structure",
    "zh_name": "间隙拆解，乐器突然变少",
    "tier1_vernacular": "原本热闹嘈杂的伴奏突然一下子冷下来，鼓停了、重音乐器收起，只剩下人声或者极微弱的乐器在回荡。",
    "tier2_suno_usage": "用来打破长时间高能量的疲劳感，形成一张一弛的对比呼吸感。",
    "tier3_example": "[Breakdown]\n鼓点完全停下，只剩轻柔气声",
    "prompt_tag": "[Breakdown]",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "outro",
    "term": "[Outro]",
    "category": "song_structure",
    "zh_name": "尾奏收尾",
    "tier1_vernacular": "歌曲最后一节交代结束的段落。歌词已经唱完，乐器慢慢完成收场交代。",
    "tier2_suno_usage": "写在歌词末尾，告诉 AI 这首歌要在这里体面平稳地收场。",
    "tier3_example": "[Outro]\n音乐渐行渐远，安静停下",
    "prompt_tag": "[Outro]",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "fade_out",
    "term": "[Fade Out]",
    "category": "song_structure",
    "zh_name": "渐弱淡出",
    "tier1_vernacular": "歌词里的路标写法，提示 AI 在最后的演奏中让声音越来越轻，直到完全听不见。",
    "tier2_suno_usage": "标注在 [Outro] 的最后一行，用来做出慢慢走远的电影感收尾。",
    "tier3_example": "[Fade Out]\n旋律重复并渐渐弱化消失",
    "prompt_tag": "[Fade Out]",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },

  // ==========================================
  // 三、演唱风格与人声情绪 (Vocals & Performance)
  // ==========================================
  {
    "id": "whisper",
    "term": "[Whisper]",
    "category": "vocals_performance",
    "zh_name": "耳边轻声细语",
    "tier1_vernacular": "像贴着耳朵在说悄悄话一样，声音充满呼吸感，轻柔、私密、安静。",
    "tier2_suno_usage": "放在想要营造私密感、告白感或夜里独白的那一句歌词上方。",
    "tier3_example": "[Whisper]\n这句只说给你一个人听",
    "prompt_tag": "[Whisper]",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "belting",
    "term": "[Belting]",
    "category": "vocals_performance",
    "zh_name": "真声高唱，不用假音的实音高唱",
    "tier1_vernacular": "不用假音偷懒，而是用饱满扎实的真声直接飚上高音，充满力量和情绪震撼力。注意保留真声高唱，不要写回怒音。",
    "tier2_suno_usage": "标注在最高潮的核心句，让主唱全力以赴真声释放情感。",
    "tier3_example": "[Belting]\n就算全世界都下起大雨",
    "prompt_tag": "[Belting]",
    "expert_status": "reviewed",
    "expert_notes": "严格遵循指示保持真声高唱，不写回怒音"
  },
  {
    "id": "falsetto",
    "term": "[Falsetto]",
    "category": "vocals_performance",
    "zh_name": "假音高音",
    "tier1_vernacular": "喉咙放松，换成轻飘飘、空灵通透的假声唱高音，听起来像羽毛拂过一样温柔漂浮。",
    "tier2_suno_usage": "用于抒情歌的情感脆弱处，制造令人怜惜的柔美听感。",
    "tier3_example": "[Falsetto]\n飞向云层最柔软的地方",
    "prompt_tag": "[Falsetto]",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "spoken_word",
    "term": "[Spoken Word]",
    "category": "vocals_performance",
    "zh_name": "念白说话",
    "tier1_vernacular": "不按旋律唱，而是像电影画外音一样认真念台词、讲故事。",
    "tier2_suno_usage": "放在歌曲开头交代背景，或者放在桥段里进行一段深情自白。",
    "tier3_example": "[Spoken Word]\n那是我们最后一次在站台相遇",
    "prompt_tag": "[Spoken Word]",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "vocal_harmonies",
    "term": "[Harmonies]",
    "category": "vocals_performance",
    "zh_name": "多声部和声",
    "tier1_vernacular": "不只一个人在唱，旁边有几个不同高低音的声音同时衬托陪衬，听起来非常宽广厚实、有层次感。",
    "tier2_suno_usage": "标记在副歌最抓耳的句子上，瞬间给声音镀上一层饱满的层次厚度。",
    "tier3_example": "[Harmonies]\n让歌声在整个夜空回荡",
    "prompt_tag": "[Harmonies]",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "vibrato",
    "term": "[Vibrato]",
    "category": "vocals_performance",
    "zh_name": "颤音尾音",
    "tier1_vernacular": "尾音拉长时像水波纹一样微微上下抖动颤动，听起来功底扎实、情感充沛深情。",
    "tier2_suno_usage": "用于慢歌长音结尾，增加老练歌唱家的叙事沧桑感或深情感。",
    "tier3_example": "[Vibrato]\n时光带不走深深的思念",
    "prompt_tag": "[Vibrato]",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "ad_lib",
    "term": "[Ad-lib]",
    "category": "vocals_performance",
    "zh_name": "即兴垫音哼唱",
    "tier1_vernacular": "歌手跟着感觉随意哼出的即兴音符，比如自由的转音、伴唱的感叹词，用来给主旋律锦上添花。",
    "tier2_suno_usage": "放在主歌词的缝隙或末尾，增加现场即兴演出的鲜活性与高级感。",
    "tier3_example": "[Ad-lib]\n自由的高音哼唱转音",
    "prompt_tag": "[Ad-lib]",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "call_and_response",
    "term": "[Call and Response]",
    "category": "vocals_performance",
    "zh_name": "呼应对唱",
    "tier1_vernacular": "你唱一句、我接一句的对答互动。像领唱喊一声，后面大家齐声接一句，非常热闹有互动感。",
    "tier2_suno_usage": "用于欢快歌曲或舞台感强烈的曲目中，营造全场互动的热闹气氛。",
    "tier3_example": "[Call and Response]\n主唱：准备好了吗？伴唱：准备好了！",
    "prompt_tag": "[Call and Response]",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "chant",
    "term": "[Chant]",
    "category": "vocals_performance",
    "zh_name": "齐声呼号喊口号",
    "tier1_vernacular": "像球场观众席所有人一起整齐大喊口号一样，声音极具冲击力和号召力。",
    "tier2_suno_usage": "放在热血高能歌曲的间隙，能瞬间点燃全场气势。",
    "tier3_example": "[Chant]\n一起往前冲，绝不回头",
    "prompt_tag": "[Chant]",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },

  // ==========================================
  // 四、主流曲风与流派氛围 (Genres & Styles)
  // ==========================================
  {
    "id": "lofi",
    "term": "Lo-fi",
    "category": "genres_and_styles",
    "zh_name": "低保真慢调",
    "tier1_vernacular": "带着黑胶唱片沙沙声、慵懒慢节奏的背景音乐，听起来特别适合深夜看书、写代码或放松发呆。",
    "tier2_suno_usage": "填在风格描述框里，适合做不吵人的背景轻音乐。",
    "tier3_example": "lo-fi hip hop, warm mellow piano, vinyl crackle, chill",
    "prompt_tag": "lo-fi hip hop, warm mellow piano, vinyl crackle, chill",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "city_pop",
    "term": "City Pop",
    "category": "genres_and_styles",
    "zh_name": "城市流行",
    "tier1_vernacular": "像八十年代开着敞篷车在海滨霓虹公路兜风一样的复古都市感，旋律轻快摩登、充满浪漫惬意。",
    "tier2_suno_usage": "填在风格描述框里，做复古都市摩登感音乐的首选。",
    "tier3_example": "city pop, sparkling synth, upbeat funk bass, nostalgic 80s",
    "prompt_tag": "city pop, sparkling synth, upbeat funk bass, nostalgic 80s",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "synthwave",
    "term": "Synthwave",
    "category": "genres_and_styles",
    "zh_name": "复古未来合成器",
    "tier1_vernacular": "浓浓的复古科幻质感，充满跳跃闪烁的电子合成器声响和坚实鼓点，像穿越进老科幻片一样。",
    "tier2_suno_usage": "适合电音迷幻、夜间疾驰或游戏主题曲。",
    "tier3_example": "synthwave, 80s retro synth, driving electro beat, neon night",
    "prompt_tag": "synthwave, 80s retro synth, driving electro beat, neon night",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "melodic_techno",
    "term": "Melodic Techno",
    "category": "genres_and_styles",
    "zh_name": "旋律铁克诺",
    "tier1_vernacular": "低沉持续的鼓点一下接一下打在心口上，伴随深邃空灵的旋律不断盘旋推进，非常让人沉浸入迷。",
    "tier2_suno_usage": "适合深夜深度专注或沉浸式电音俱乐部氛围。",
    "tier3_example": "melodic techno, deep hypnotic pulse, atmospheric synth",
    "prompt_tag": "melodic techno, deep hypnotic pulse, atmospheric synth",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "shoegaze",
    "term": "Shoegaze",
    "category": "genres_and_styles",
    "zh_name": "自赏摇滚",
    "tier1_vernacular": "吉他声音巨大且层层叠叠包裹成一面声音的海洋墙壁，人声像浮在云雾里一样飘渺梦幻。",
    "tier2_suno_usage": "想要宏大模糊、沉浸梦幻的摇滚听感时填入此词。",
    "tier3_example": "shoegaze, dreamy guitar wall of sound, ethereal floating vocal",
    "prompt_tag": "shoegaze, dreamy guitar wall of sound, ethereal floating vocal",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "math_rock",
    "term": "Math Rock",
    "category": "genres_and_styles",
    "zh_name": "数学摇滚",
    "tier1_vernacular": "吉他弹得非常精巧跳跃，节拍常常出其不意地变动变换，听起来像精密的钟表齿轮在灵动起舞。",
    "tier2_suno_usage": "想要新奇灵动、器乐技巧感极强的摇滚乐时使用。",
    "tier3_example": "math rock, clean tapping guitar, intricate rhythm, brisk",
    "prompt_tag": "math rock, clean tapping guitar, intricate rhythm, brisk",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "trap",
    "term": "Trap",
    "category": "genres_and_styles",
    "zh_name": "陷阱说唱",
    "tier1_vernacular": "标志性的轰鸣重低音震感，搭配像机枪一样快速滚动的金属打击碎拍，说唱界最流行的暗黑帅气节拍。",
    "tier2_suno_usage": "做现代帅气说唱、街头潮流音乐的核心风格词。",
    "tier3_example": "trap, deep booming sub-bass, fast rolling hi-hats, dark flow",
    "prompt_tag": "trap, deep booming sub-bass, fast rolling hi-hats, dark flow",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "rb_ballad",
    "term": "R&B Ballad",
    "category": "genres_and_styles",
    "zh_name": "节奏布鲁斯慢情歌",
    "tier1_vernacular": "温暖柔和的电钢琴伴奏，歌手嗓音细腻缠绵、转音顺滑，唱出非常真挚动人的深情爱意。",
    "tier2_suno_usage": "做深情对唱、浪漫抒情情歌的首选题材。",
    "tier3_example": "r&b ballad, smooth electric piano, soulful vocal runs, gentle beat",
    "prompt_tag": "r&b ballad, smooth electric piano, soulful vocal runs, gentle beat",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "indie_folk",
    "term": "Indie Folk",
    "category": "genres_and_styles",
    "zh_name": "独立民谣",
    "tier1_vernacular": "一把原声木吉他清脆弹奏，伴随朴实真诚的人声缓缓唱歌，像坐在山间清晨的阳光下吹着微风。",
    "tier2_suno_usage": "纯净治愈系、文艺走心歌曲的最佳选择。",
    "tier3_example": "indie folk, acoustic guitar, warm intimate vocal, peaceful breeze",
    "prompt_tag": "indie folk, acoustic guitar, warm intimate vocal, peaceful breeze",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "future_bass",
    "term": "Future Bass",
    "category": "genres_and_styles",
    "zh_name": "未来低音",
    "tier1_vernacular": "像弹簧一样有弹性跳跃的明亮合成器音色，高潮爆发时充满欢快跳动的青春能量与梦幻色彩。",
    "tier2_suno_usage": "做动漫感、青春元气、电竞高能音乐的绝佳标签。",
    "tier3_example": "future bass, bouncy supersaw synth, upbeat playful drop",
    "prompt_tag": "future bass, bouncy supersaw synth, upbeat playful drop",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "orchestral_cinematic",
    "term": "Cinematic Orchestral",
    "category": "genres_and_styles",
    "zh_name": "史诗电影管弦乐",
    "tier1_vernacular": "整支大型交响乐团齐奏，恢弘的小提琴群配上震撼的大鼓轰鸣，像坐在电影院看好莱坞大片一样震撼。",
    "tier2_suno_usage": "适合做宏大预告片、游戏大决战背景配乐。",
    "tier3_example": "cinematic orchestral, sweeping strings, thunderous brass, epic",
    "prompt_tag": "cinematic orchestral, sweeping strings, thunderous brass, epic",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },

  // ==========================================
  // 五、编曲与声学制作参数 (Production Parameters)
  // ==========================================
  {
    "id": "bpm",
    "term": "BPM",
    "category": "production_params",
    "zh_name": "每分钟节拍数，决定快慢",
    "tier1_vernacular": "歌曲的心跳频率。数字越小越慢，像慢步闲聊；数字越大越快，像跑步或狂欢跳舞。",
    "tier2_suno_usage": "可以把具体速度写进风格框，比如 85 bpm 代表抒情慢歌，128 bpm 代表动感舞曲。",
    "tier3_example": "85 bpm 适合慢情歌，120 bpm 适合常规流行，128 bpm 适合欢快跳舞。",
    "prompt_tag": "120 bpm",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "key_signature",
    "term": "Key",
    "category": "production_params",
    "zh_name": "调式与调性，决定明暗色彩",
    "tier1_vernacular": "歌曲的底色明暗。大调通常听起来明媚、开朗、阳光；小调通常听起来忧伤、深沉、难过。",
    "tier2_suno_usage": "可在风格框指定调性，例如 C major 阳光开朗，A minor 忧郁伤感。",
    "tier3_example": "C major, bright and cheerful 或 A minor, melancholic and sad",
    "prompt_tag": "C major",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "reverb",
    "term": "Reverb",
    "category": "production_params",
    "zh_name": "空间混响，像在房间还是大礼堂",
    "tier1_vernacular": "声音反射带来的空间感。没有混响像贴在耳朵边说话；混响大就像站在空旷大教堂或浴室里唱歌一样余音缭绕。",
    "tier2_suno_usage": "想让人声贴耳写 dry intimate vocal；想要梦幻辽阔写 massive ethereal reverb。",
    "tier3_example": "dry vocal, close-mic 或 spacious hall reverb",
    "prompt_tag": "spacious hall reverb",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  },
  {
    "id": "acoustic_vs_electronic",
    "term": "Acoustic vs Electronic",
    "category": "production_params",
    "zh_name": "原声乐器与电子合成器",
    "tier1_vernacular": "原声是指木吉他、真钢琴这种真实物理乐器发出的质朴声音；电子是指用电脑芯片模拟出的现代合成音色。",
    "tier2_suno_usage": "想要自然质朴选 acoustic；想要现代电音感选 electronic 或 synth。",
    "tier3_example": "acoustic: 原声木吉他与温暖钢琴；electronic: 现代律动电音与合成器",
    "prompt_tag": "acoustic guitar, warm piano",
    "expert_status": "reviewed",
    "expert_notes": "去括号"
  }
];

// 严格检验：确保全词库中文无任何括号 () （） 和 [中文] 【中文】
let errors = 0;
glossary.forEach(item => {
  const checkFields = [item.zh_name, item.tier1_vernacular, item.tier2_suno_usage];
  checkFields.forEach(f => {
    if (/[()（）]/.test(f)) {
      console.error(`[Bracket Error] ${item.id}: "${f}" 包含括号！`);
      errors++;
    }
    if (/\[中文\]|【中文】/.test(f)) {
      console.error(`[Tag Error] ${item.id}: 包含【中文】标识！`);
      errors++;
    }
  });
});

if (errors > 0) {
  console.error(`校验失败，存在 ${errors} 处违规格式！`);
  process.exit(1);
}

const targetPath = path.join(__dirname, '..', 'src', 'data', 'glossary.json');
fs.writeFileSync(targetPath, JSON.stringify(glossary, null, 2), 'utf-8');
console.log(`✅ glossary.json 写入成功！共 ${glossary.length} 个词条，0 括号，0 格式违规。`);
